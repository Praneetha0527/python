import sqlite3
import tkinter as tk
from tkinter import ttk

def fetch_scores():
    conn = sqlite3.connect('highscore.db')
    cur = conn.cursor()

    # Query to fetch all records from the 'scores' table
    cur.execute("SELECT player, score FROM scores")
    rows = cur.fetchall()

    conn.close()
    return rows

def display_scores():
    # Fetch the data from the database
    scores = fetch_scores()

    # Create a new window
    window = tk.Tk()
    window.title("High Scores")

    # Set up a Treeview widget to display the scores
    tree = ttk.Treeview(window, columns=("Player", "Score"), show="headings")
    tree.heading("Player", text="Player")
    tree.heading("Score", text="Score")

    # Insert the fetched data into the Treeview
    for score in scores:
        tree.insert("", "end", values=score)

    # Pack the Treeview widget
    tree.pack(padx=10, pady=10)

    # Button to close the window
    close_button = tk.Button(window, text="Close", command=window.quit)
    close_button.pack(pady=5)

    # Run the Tkinter main loop
    window.mainloop()

if __name__ == "__main__":
    display_scores()