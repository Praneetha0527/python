import pygame
import random
import sqlite3

# Initialize
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Cane Shooting Game")
clock = pygame.time.Clock()

# Colors
WHITE = (255, 255, 255)
RED = (255, 60, 60)
NEON = (0, 255, 255)
BLACK = (0, 0, 0)

# Fonts
font = pygame.font.SysFont("comicsansms", 36)
big_font = pygame.font.SysFont("comicsansms", 64)

# DB Setup
conn = sqlite3.connect("highscore.db")
cur = conn.cursor()
cur.execute("CREATE TABLE IF NOT EXISTS scores (player TEXT, score INTEGER)")
conn.commit()

def save_score(player, score):
    cur.execute("INSERT INTO scores VALUES (?, ?)", (player, score))
    conn.commit()

def get_high_score():
    cur.execute("SELECT MAX(score) FROM scores")
    row = cur.fetchone()
    return row[0] if row[0] else 0

# Classes
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((60, 60), pygame.SRCALPHA)
        pygame.draw.rect(self.image, NEON, (0, 0, 60, 60), border_radius=20)
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT - 50))

    def update(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 10:
            self.rect.x -= 8
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH - 10:
            self.rect.x += 8

class Cane(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((6, 20))
        self.image.fill(RED)
        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        self.rect.y -= 10
        if self.rect.bottom < 0:
            self.kill()

class Snowball(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((40, 40), pygame.SRCALPHA)
        pygame.draw.circle(self.image, WHITE, (20, 20), 20)
        self.rect = self.image.get_rect(center=(random.randint(40, WIDTH-40), -40))
        self.speed = random.randint(3, 6)

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > HEIGHT:
            self.kill()

# Groups
player_sprite = Player()
player_group = pygame.sprite.GroupSingle(player_sprite)
canes = pygame.sprite.Group()
snowballs = pygame.sprite.Group()

# Game States
score = 0
high_score = get_high_score()
running = True
menu = True
game_over = False
frame = 0
MAX_TIME = 60  # seconds
start_ticks = pygame.time.get_ticks()
player_name = ""

# Buttons
def draw_glow_button(text, pos, hover=False):
    glow_color = NEON if not hover else WHITE
    text_surf = font.render(text, True, glow_color)
    glow = pygame.Surface((text_surf.get_width()+20, text_surf.get_height()+20), pygame.SRCALPHA)
    pygame.draw.rect(glow, glow_color + (80,), glow.get_rect(), border_radius=15)
    screen.blit(glow, (pos[0]-10, pos[1]-10))
    screen.blit(text_surf, pos)
    return text_surf.get_rect(topleft=pos)

# Player Name Input
input_active = True
input_text = ""
def get_player_name():
    global input_text, input_active, player_name
    while input_active:
        screen.fill(BLACK)
        prompt = font.render("Enter your name:", True, WHITE)
        name_box = font.render(input_text + "|", True, NEON)
        screen.blit(prompt, (WIDTH//2 - prompt.get_width()//2, 200))
        screen.blit(name_box, (WIDTH//2 - name_box.get_width()//2, 270))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN and input_text.strip() != "":
                    player_name = input_text.strip()
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]
                else:
                    if len(input_text) < 12:
                        input_text += event.unicode
        pygame.display.update()
        clock.tick(60)

# Main Menu
def main_menu():
    global menu
    while menu:
        screen.fill(BLACK)
        title = big_font.render("CANE SHOOTER", True, NEON)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 100))

        mx, my = pygame.mouse.get_pos()
        start_rect = draw_glow_button("Start Game", (WIDTH//2 - 100, 250), 250 < my < 300)
        quit_rect = draw_glow_button("Quit", (WIDTH//2 - 60, 330), 330 < my < 380)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_rect.collidepoint((mx, my)):
                    menu = False
                elif quit_rect.collidepoint((mx, my)):
                    pygame.quit()
                    exit()

        pygame.display.update()
        clock.tick(60)

main_menu()
get_player_name()

# Game Loop
while running:
    frame += 1
    screen.fill((10, 10, 30))

    elapsed_seconds = (pygame.time.get_ticks() - start_ticks) // 1000
    time_left = MAX_TIME - elapsed_seconds

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            save_score(player_name, score)
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            cane = Cane(player_sprite.rect.centerx, player_sprite.rect.top)
            canes.add(cane)

    keys = pygame.key.get_pressed()
    player_group.update(keys)
    canes.update()
    snowballs.update()

    if frame % 30 == 0:
        snowballs.add(Snowball())

    hits = pygame.sprite.groupcollide(snowballs, canes, True, True)
    if hits:
        score += 10

    for snowball in snowballs:
        if snowball.rect.bottom >= HEIGHT:
            score = max(0, score - 5)
            snowball.kill()

    player_group.draw(screen)
    canes.draw(screen)
    snowballs.draw(screen)

    score_text = font.render(f"Score: {score}", True, WHITE)
    high_text = font.render(f"High Score: {high_score}", True, WHITE)
    timer_text = font.render(f"Time: {time_left}", True, WHITE)
    screen.blit(score_text, (10, 10))
    screen.blit(high_text, (10, 50))
    screen.blit(timer_text, (WIDTH - 180, 10))

    pygame.display.update()
    clock.tick(60)

    if time_left <= 0:
        save_score(player_name, score)
        running = False
        game_over = True

# Game Over Screen
if game_over:
    while True:
        screen.fill((10, 10, 30))
        over = big_font.render("GAME OVER", True, RED)
        final = font.render(f"Final Score: {score}", True, WHITE)
        best = font.render(f"High Score: {get_high_score()}", True, WHITE)
        msg = font.render("Press ENTER to return to menu", True, NEON)

        screen.blit(over, (WIDTH//2 - over.get_width()//2, 150))
        screen.blit(final, (WIDTH//2 - final.get_width()//2, 250))
        screen.blit(best, (WIDTH//2 - best.get_width()//2, 300))
        screen.blit(msg, (WIDTH//2 - msg.get_width()//2, 380))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                score = 0
                player_sprite.rect.centerx = WIDTH // 2
                canes.empty()
                snowballs.empty()
                start_ticks = pygame.time.get_ticks()
                game_over = False
                menu = True
                main_menu()
                get_player_name()
                running = True

        pygame.display.update()
        clock.tick(60)

pygame.quit()